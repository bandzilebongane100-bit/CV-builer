
'use client';

import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Plus, Trash2, Sparkles, Wand2 } from 'lucide-react';
import { CVData, Experience, Education, Skill } from '@/lib/types';
import { generateBulletPoints } from '@/ai/flows/generate-impactful-bullet-points';
import { toast } from '@/hooks/use-toast';

interface CVEditorProps {
  data: CVData;
  onChange: (data: CVData) => void;
}

export const CVEditor: React.FC<CVEditorProps> = ({ data, onChange }) => {
  const [isGenerating, setIsGenerating] = React.useState(false);

  const updatePersonalInfo = (field: string, value: string) => {
    onChange({
      ...data,
      personalInfo: { ...data.personalInfo, [field]: value }
    });
  };

  const addExperience = () => {
    const newExp: Experience = {
      id: crypto.randomUUID(),
      company: '',
      role: '',
      duration: '',
      description: '',
      bulletPoints: []
    };
    onChange({ ...data, experience: [...data.experience, newExp] });
  };

  const updateExperience = (id: string, field: string, value: string) => {
    onChange({
      ...data,
      experience: data.experience.map(exp => exp.id === id ? { ...exp, [field]: value } : exp)
    });
  };

  const removeExperience = (id: string) => {
    onChange({
      ...data,
      experience: data.experience.filter(exp => exp.id !== id)
    });
  };

  const handleAIDescription = async (exp: Experience) => {
    if (!exp.role || !exp.company) {
      toast({ title: 'Error', description: 'Please fill in the role and company first.', variant: 'destructive' });
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateBulletPoints({
        role: exp.role,
        company: exp.company,
        duration: exp.duration,
        responsibilities: exp.description || 'General professional responsibilities',
        achievements: 'Key professional milestones'
      });
      
      const aiText = result.bulletPoints.join('\n');
      updateExperience(exp.id, 'description', aiText);
      toast({ title: 'Success', description: 'Bullet points generated successfully!' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to generate content. Please try again.', variant: 'destructive' });
    } finally {
      setIsGenerating(false);
    }
  };

  const addEducation = () => {
    const newEdu: Education = {
      id: crypto.randomUUID(),
      institution: '',
      degree: '',
      duration: ''
    };
    onChange({ ...data, education: [...data.education, newEdu] });
  };

  const updateEducation = (id: string, field: string, value: string) => {
    onChange({
      ...data,
      education: data.education.map(edu => edu.id === id ? { ...edu, [field]: value } : edu)
    });
  };

  const addSkill = () => {
    const newSkill: Skill = { id: crypto.randomUUID(), name: '' };
    onChange({ ...data, skills: [...data.skills, newSkill] });
  };

  const updateSkill = (id: string, value: string) => {
    onChange({
      ...data,
      skills: data.skills.map(s => s.id === id ? { ...s, name: value } : s)
    });
  };

  return (
    <div className="space-y-6 pb-20">
      <Card className="border-none shadow-sm bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-headline flex items-center gap-2">
            Personal Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input 
                value={data.personalInfo.fullName} 
                onChange={(e) => updatePersonalInfo('fullName', e.target.value)}
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input 
                type="email"
                value={data.personalInfo.email} 
                onChange={(e) => updatePersonalInfo('email', e.target.value)}
                placeholder="john@example.com"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input 
                value={data.personalInfo.phone} 
                onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                placeholder="+1 234 567 890"
              />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Input 
                value={data.personalInfo.location} 
                onChange={(e) => updatePersonalInfo('location', e.target.value)}
                placeholder="New York, USA"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Professional Summary</Label>
            <Textarea 
              value={data.personalInfo.summary} 
              onChange={(e) => updatePersonalInfo('summary', e.target.value)}
              placeholder="Elevator pitch about yourself..."
              className="min-h-[100px]"
            />
          </div>
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="w-full space-y-4">
        <AccordionItem value="experience" className="border-none">
          <Card className="shadow-sm">
            <AccordionTrigger className="px-6 hover:no-underline">
              <CardTitle className="text-lg font-headline flex items-center gap-2">
                Work Experience
              </CardTitle>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6 pt-0">
              <div className="space-y-6">
                {data.experience.map((exp) => (
                  <div key={exp.id} className="relative p-4 border rounded-lg space-y-4 bg-background/50">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-2 right-2 text-destructive"
                      onClick={() => removeExperience(exp.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Company</Label>
                        <Input value={exp.company} onChange={(e) => updateExperience(exp.id, 'company', e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Role</Label>
                        <Input value={exp.role} onChange={(e) => updateExperience(exp.id, 'role', e.target.value)} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Duration</Label>
                      <Input value={exp.duration} onChange={(e) => updateExperience(exp.id, 'duration', e.target.value)} placeholder="Jan 2020 - Present" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Description & Achievements</Label>
                        <Button 
                          size="sm" 
                          variant="secondary" 
                          className="h-8 text-xs gap-1"
                          onClick={() => handleAIDescription(exp)}
                          disabled={isGenerating}
                        >
                          <Sparkles className="w-3 h-3" />
                          AI Polish
                        </Button>
                      </div>
                      <Textarea 
                        value={exp.description} 
                        onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                        className="min-h-[120px]"
                        placeholder="Bullet points of what you did..."
                      />
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full dashed border-dashed border-2 h-12" onClick={addExperience}>
                  <Plus className="mr-2 h-4 w-4" /> Add Experience
                </Button>
              </div>
            </AccordionContent>
          </Card>
        </AccordionItem>

        <AccordionItem value="education" className="border-none">
          <Card className="shadow-sm">
            <AccordionTrigger className="px-6 hover:no-underline">
              <CardTitle className="text-lg font-headline flex items-center gap-2">
                Education
              </CardTitle>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6 pt-0">
              <div className="space-y-4">
                {data.education.map((edu) => (
                  <div key={edu.id} className="p-4 border rounded-lg space-y-4 bg-background/50">
                    <div className="space-y-2">
                      <Label>Institution</Label>
                      <Input value={edu.institution} onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Degree</Label>
                        <Input value={edu.degree} onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Duration</Label>
                        <Input value={edu.duration} onChange={(e) => updateEducation(edu.id, 'duration', e.target.value)} />
                      </div>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full border-dashed" onClick={addEducation}>
                  <Plus className="mr-2 h-4 w-4" /> Add Education
                </Button>
              </div>
            </AccordionContent>
          </Card>
        </AccordionItem>

        <AccordionItem value="skills" className="border-none">
          <Card className="shadow-sm">
            <AccordionTrigger className="px-6 hover:no-underline">
              <CardTitle className="text-lg font-headline flex items-center gap-2">
                Skills
              </CardTitle>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6 pt-0">
              <div className="grid grid-cols-2 gap-2">
                {data.skills.map((skill) => (
                  <Input 
                    key={skill.id} 
                    value={skill.name} 
                    onChange={(e) => updateSkill(skill.id, e.target.value)}
                    placeholder="e.g. React.js"
                    className="h-9"
                  />
                ))}
                <Button variant="outline" size="sm" className="h-9 border-dashed" onClick={addSkill}>
                  <Plus className="mr-2 h-4 w-4" /> Add Skill
                </Button>
              </div>
            </AccordionContent>
          </Card>
        </AccordionItem>
      </Accordion>
    </div>
  );
};
