
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Target, Sparkles, Loader2 } from 'lucide-react';
import { CVData } from '@/lib/types';
import { suggestCvImprovements } from '@/ai/flows/suggest-cv-improvements';
import { toast } from '@/hooks/use-toast';

interface JobAlignerProps {
  cvData: CVData;
}

export const JobAligner: React.FC<JobAlignerProps> = ({ cvData }) => {
  const [jobDescription, setJobDescription] = React.useState('');
  const [analysis, setAnalysis] = React.useState<string | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleAnalyze = async () => {
    if (!jobDescription) {
      toast({ title: 'Error', description: 'Please paste a job description first.', variant: 'destructive' });
      return;
    }

    setIsLoading(true);
    try {
      // Create a simplified string of the CV content for analysis
      const cvText = `
        Summary: ${cvData.personalInfo.summary}
        Experience: ${cvData.experience.map(e => `${e.role} at ${e.company}: ${e.description}`).join('\n')}
        Education: ${cvData.education.map(e => `${e.degree} at ${e.institution}`).join('\n')}
        Skills: ${cvData.skills.map(s => s.name).join(', ')}
      `;

      const result = await suggestCvImprovements({
        cvContent: cvText,
        jobDescription: jobDescription
      });

      setAnalysis(result.improvements);
      toast({ title: 'Analysis Complete', description: 'Check the suggestions to improve your resume.' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to analyze alignment.', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="border-none shadow-sm bg-white overflow-hidden">
      <CardHeader className="bg-secondary/20 border-b">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-accent" />
          <CardTitle className="text-lg">Job Alignment Tool</CardTitle>
        </div>
        <CardDescription>Paste the job description you're applying for to get AI-powered tailoring suggestions.</CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Textarea 
            placeholder="Paste job description here..." 
            className="min-h-[150px] resize-none focus-visible:ring-accent"
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
          />
        </div>
        <Button 
          className="w-full bg-accent hover:bg-accent/90" 
          onClick={handleAnalyze}
          disabled={isLoading}
        >
          {isLoading ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</>
          ) : (
            <><Sparkles className="mr-2 h-4 w-4" /> Tailor My Resume</>
          )}
        </Button>

        {analysis && (
          <div className="mt-6 p-4 rounded-lg bg-secondary/30 border border-secondary text-sm space-y-3">
            <h4 className="font-bold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-accent" />
              Strategic Recommendations:
            </h4>
            <div className="prose prose-sm text-foreground/80 leading-relaxed whitespace-pre-line">
              {analysis}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
