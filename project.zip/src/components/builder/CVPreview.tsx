
'use client';

import React from 'react';
import { CVData } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Mail, Phone, MapPin, Globe } from 'lucide-react';

interface CVPreviewProps {
  data: CVData;
}

export const CVPreview: React.FC<CVPreviewProps> = ({ data }) => {
  const { personalInfo, experience, education, skills, template } = data;

  const renderClassic = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-2 border-b-2 border-primary pb-6">
        <h1 className="text-4xl font-preview font-bold uppercase tracking-widest text-primary">
          {personalInfo.fullName || 'YOUR NAME'}
        </h1>
        <div className="flex justify-center flex-wrap gap-4 text-sm text-muted-foreground uppercase font-medium">
          {personalInfo.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {personalInfo.email}</span>}
          {personalInfo.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {personalInfo.phone}</span>}
          {personalInfo.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {personalInfo.location}</span>}
        </div>
      </div>

      {/* Summary */}
      {personalInfo.summary && (
        <section className="space-y-2">
          <h2 className="text-lg font-preview font-bold uppercase border-b border-primary/20 pb-1 text-primary">
            Professional Summary
          </h2>
          <p className="text-sm leading-relaxed text-foreground">
            {personalInfo.summary}
          </p>
        </section>
      )}

      {/* Experience */}
      <section className="space-y-4">
        <h2 className="text-lg font-preview font-bold uppercase border-b border-primary/20 pb-1 text-primary">
          Experience
        </h2>
        <div className="space-y-6">
          {experience.map((exp) => (
            <div key={exp.id} className="space-y-1">
              <div className="flex justify-between items-baseline">
                <h3 className="font-bold text-base">{exp.role || 'Position Title'}</h3>
                <span className="text-xs font-medium text-muted-foreground italic">{exp.duration}</span>
              </div>
              <p className="text-sm font-semibold text-accent">{exp.company || 'Company Name'}</p>
              <div className="text-sm leading-relaxed whitespace-pre-line text-muted-foreground">
                {exp.description}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Education */}
      <section className="space-y-4">
        <h2 className="text-lg font-preview font-bold uppercase border-b border-primary/20 pb-1 text-primary">
          Education
        </h2>
        <div className="space-y-4">
          {education.map((edu) => (
            <div key={edu.id} className="flex justify-between items-baseline">
              <div>
                <h3 className="font-bold text-sm">{edu.institution || 'University Name'}</h3>
                <p className="text-sm">{edu.degree || 'Degree Program'}</p>
              </div>
              <span className="text-xs text-muted-foreground">{edu.duration}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Skills */}
      <section className="space-y-4">
        <h2 className="text-lg font-preview font-bold uppercase border-b border-primary/20 pb-1 text-primary">
          Skills
        </h2>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          {skills.map((skill) => (
            <span key={skill.id} className="text-sm font-medium">• {skill.name}</span>
          ))}
        </div>
      </section>
    </div>
  );

  const renderModern = () => (
    <div className="grid grid-cols-12 h-full gap-0">
      {/* Sidebar */}
      <div className="col-span-4 bg-primary text-white p-8 space-y-8 h-full min-h-[inherit]">
        <div className="space-y-2">
          <h1 className="text-2xl font-preview font-bold leading-tight">
            {personalInfo.fullName || 'YOUR NAME'}
          </h1>
          <p className="text-accent text-sm font-medium tracking-wide uppercase">
            {personalInfo.jobTitle || 'Professional Role'}
          </p>
        </div>

        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest border-b border-accent/40 pb-1">Contact</h2>
          <div className="space-y-3 text-xs opacity-90">
             {personalInfo.email && <div className="flex items-center gap-2"><Mail className="w-3 h-3" /> {personalInfo.email}</div>}
             {personalInfo.phone && <div className="flex items-center gap-2"><Phone className="w-3 h-3" /> {personalInfo.phone}</div>}
             {personalInfo.location && <div className="flex items-center gap-2"><MapPin className="w-3 h-3" /> {personalInfo.location}</div>}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest border-b border-accent/40 pb-1">Skills</h2>
          <div className="space-y-2 text-xs">
            {skills.map(s => (
              <div key={s.id} className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-accent rounded-full" />
                {s.name}
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest border-b border-accent/40 pb-1">Education</h2>
          {education.map(edu => (
            <div key={edu.id} className="space-y-1">
              <p className="text-xs font-bold">{edu.degree}</p>
              <p className="text-[10px] opacity-70">{edu.institution}</p>
              <p className="text-[10px] opacity-70 italic">{edu.duration}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="col-span-8 p-8 space-y-8 bg-white">
        <section className="space-y-2">
           <h2 className="text-lg font-preview font-bold text-primary uppercase border-l-4 border-accent pl-3">Summary</h2>
           <p className="text-sm leading-relaxed text-muted-foreground">{personalInfo.summary}</p>
        </section>

        <section className="space-y-6">
           <h2 className="text-lg font-preview font-bold text-primary uppercase border-l-4 border-accent pl-3">Work Experience</h2>
           <div className="space-y-8">
             {experience.map(exp => (
               <div key={exp.id} className="space-y-2">
                 <div className="flex justify-between items-baseline">
                   <h3 className="text-sm font-bold text-foreground">{exp.role}</h3>
                   <span className="text-[10px] font-bold text-accent uppercase">{exp.duration}</span>
                 </div>
                 <p className="text-xs font-semibold text-primary/80 italic">{exp.company}</p>
                 <div className="text-xs text-muted-foreground leading-relaxed whitespace-pre-line">
                   {exp.description}
                 </div>
               </div>
             ))}
           </div>
        </section>
      </div>
    </div>
  );

  return (
    <div className="cv-preview-container bg-white shadow-xl mx-auto overflow-hidden min-h-[297mm] w-[210mm] transition-all duration-500 ease-in-out">
      {template === 'modern' ? renderModern() : renderClassic()}
    </div>
  );
};
