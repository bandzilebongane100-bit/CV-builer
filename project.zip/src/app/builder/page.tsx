
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CVEditor } from '@/components/builder/CVEditor';
import { CVPreview } from '@/components/builder/CVPreview';
import { JobAligner } from '@/components/builder/JobAligner';
import { CVData, ResumeTemplate } from '@/lib/types';
import { FileText, Download, Save, Layout, Target, Settings, ChevronLeft, Columns, Eye } from 'lucide-react';
import Link from 'next/link';
import { toast } from '@/hooks/use-toast';
import { Toaster } from '@/components/ui/toaster';

const INITIAL_DATA: CVData = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    jobTitle: '',
    summary: ''
  },
  experience: [],
  education: [],
  skills: [],
  template: 'classic'
};

export default function BuilderPage() {
  const [data, setData] = React.useState<CVData>(INITIAL_DATA);
  const [activeTab, setActiveTab] = React.useState('editor');
  
  // Load from local storage on mount
  React.useEffect(() => {
    const saved = localStorage.getItem('elite_draft_cv');
    if (saved) {
      try {
        setData(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load saved CV');
      }
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('elite_draft_cv', JSON.stringify(data));
    toast({ title: 'Progress Saved', description: 'Your CV draft has been saved locally.' });
  };

  const handleExport = () => {
    window.print();
  };

  const toggleTemplate = (t: ResumeTemplate) => {
    setData({ ...data, template: t });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Toaster />
      
      {/* Header Bar */}
      <header className="h-14 bg-primary text-white flex items-center justify-between px-4 sticky top-0 z-50 no-print">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
              <ChevronLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-accent" />
            <span className="font-bold tracking-tight">EliteDraft Workspace</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1 bg-white/10 p-1 rounded-md">
            <Button 
              size="sm" 
              variant={data.template === 'classic' ? 'secondary' : 'ghost'} 
              className="h-8 text-xs"
              onClick={() => toggleTemplate('classic')}
            >
              Classic
            </Button>
            <Button 
              size="sm" 
              variant={data.template === 'modern' ? 'secondary' : 'ghost'} 
              className="h-8 text-xs"
              onClick={() => toggleTemplate('modern')}
            >
              Modern
            </Button>
          </div>
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/10" onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" />
            Save Draft
          </Button>
          <Button size="sm" className="bg-accent hover:bg-accent/90 text-white" onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex overflow-hidden">
        {/* Mobile View Toggle */}
        <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-primary rounded-full shadow-2xl p-1 no-print">
          <div className="flex items-center">
             <Button 
               variant={activeTab === 'editor' ? 'secondary' : 'ghost'} 
               size="sm" 
               className="rounded-full h-10 px-6 text-xs"
               onClick={() => setActiveTab('editor')}
             >
               Editor
             </Button>
             <Button 
               variant={activeTab === 'preview' ? 'secondary' : 'ghost'} 
               size="sm" 
               className="rounded-full h-10 px-6 text-xs"
               onClick={() => setActiveTab('preview')}
             >
               Preview
             </Button>
          </div>
        </div>

        {/* Left Pane: Editor */}
        <div className={cn(
          "w-full md:w-[45%] border-r overflow-y-auto no-print",
          activeTab === 'preview' ? 'hidden md:block' : 'block'
        )}>
          <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-8">
             <Tabs defaultValue="content" className="w-full">
               <TabsList className="grid w-full grid-cols-2 mb-8 bg-muted/50 p-1">
                 <TabsTrigger value="content" className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                   <Columns className="w-4 h-4" /> Content
                 </TabsTrigger>
                 <TabsTrigger value="alignment" className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                   <Target className="w-4 h-4" /> AI Tailor
                 </TabsTrigger>
               </TabsList>
               
               <TabsContent value="content">
                 <CVEditor data={data} onChange={setData} />
               </TabsContent>
               
               <TabsContent value="alignment">
                 <JobAligner cvData={data} />
               </TabsContent>
             </Tabs>
          </div>
        </div>

        {/* Right Pane: Preview */}
        <div className={cn(
          "flex-1 bg-muted/20 overflow-y-auto p-4 md:p-12 flex justify-center print:bg-white print:p-0",
          activeTab === 'editor' ? 'hidden md:flex' : 'flex'
        )}>
          <CVPreview data={data} />
        </div>
      </main>
    </div>
  );
}
