
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { FileText, Sparkles, Layout, Target, Download, CheckCircle2 } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-cv');

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <Link className="flex items-center justify-center gap-2" href="/">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight font-headline text-primary">EliteDraft</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:text-accent transition-colors mt-2" href="#features">
            Features
          </Link>
          <Link href="/builder">
            <Button size="sm" variant="default" className="bg-accent hover:bg-accent/90">
              Launch App
            </Button>
          </Link>
        </nav>
      </header>

      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold text-accent border-accent/20 bg-accent/5 mb-2">
                    <Sparkles className="w-3 h-3 mr-1" />
                    AI-Powered Excellence
                  </div>
                  <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl font-headline text-primary">
                    Your Dream Career Starts with an <span className="text-accent">Elite Draft</span>
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    The intelligence of AI meets world-class design. Build professional, ATS-optimized resumes in minutes.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/builder">
                    <Button size="lg" className="bg-accent hover:bg-accent/90 text-white w-full min-[400px]:w-auto">
                      Start Building Now
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="w-full min-[400px]:w-auto">
                    View Templates
                  </Button>
                </div>
              </div>
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-accent to-primary rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-white p-2 rounded-xl shadow-2xl">
                   {heroImage && (
                    <Image
                      src={heroImage.imageUrl}
                      alt={heroImage.description}
                      width={1200}
                      height={800}
                      className="rounded-lg object-cover"
                      data-ai-hint={heroImage.imageHint}
                      priority
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">Engineered for Success</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  More than just a builder. EliteDraft uses advanced algorithms to ensure you stand out.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col items-center space-y-4 p-6 rounded-2xl border bg-background hover:shadow-lg transition-shadow">
                <div className="p-3 bg-secondary rounded-xl">
                  <Sparkles className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-primary">AI Content Tool</h3>
                <p className="text-center text-muted-foreground">
                  Struggling for words? Generate high-impact bullet points that quantify your achievements automatically.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 p-6 rounded-2xl border bg-background hover:shadow-lg transition-shadow">
                <div className="p-3 bg-secondary rounded-xl">
                  <Target className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-primary">Job Alignment</h3>
                <p className="text-center text-muted-foreground">
                  Paste a job description and our AI will suggest specific keywords and phrasing to beat the ATS.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 p-6 rounded-2xl border bg-background hover:shadow-lg transition-shadow">
                <div className="p-3 bg-secondary rounded-xl">
                  <Layout className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-primary">Live Preview</h3>
                <p className="text-center text-muted-foreground">
                  See your professional document update in real-time as you type, perfectly formatted for A4.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-secondary/30">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-primary font-headline">Ready in Minutes, Exported in Seconds</h2>
                <ul className="grid gap-4">
                  {[
                    "One-click PDF Export",
                    "ATS-Friendly Templates",
                    "No Login Required to Start",
                    "Cloud Sync & Persistence"
                  ].map((text, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-accent" />
                      <span className="font-medium">{text}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/builder">
                  <Button className="mt-4 bg-primary text-white hover:bg-primary/90">
                    Get Started <Download className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
              <div className="flex justify-center">
                <div className="relative w-full max-w-[400px] aspect-[1/1.4] bg-white shadow-2xl rounded-lg p-8 border">
                   <div className="h-8 w-3/4 bg-muted rounded mb-4" />
                   <div className="h-4 w-1/2 bg-muted/60 rounded mb-8" />
                   <div className="space-y-4">
                     <div className="h-3 w-full bg-muted/40 rounded" />
                     <div className="h-3 w-full bg-muted/40 rounded" />
                     <div className="h-3 w-5/6 bg-muted/40 rounded" />
                   </div>
                   <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-accent rounded-full flex items-center justify-center shadow-lg">
                      <Download className="text-white w-8 h-8" />
                   </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-6 md:py-12 bg-white">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 px-4 md:px-6">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-accent" />
            <span className="font-bold">EliteDraft</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 EliteDraft. All rights reserved.</p>
          <div className="flex gap-4">
            <Link className="text-sm hover:underline underline-offset-4" href="#">Privacy</Link>
            <Link className="text-sm hover:underline underline-offset-4" href="#">Terms</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
