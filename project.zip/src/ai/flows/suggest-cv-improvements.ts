'use server';
/**
 * @fileOverview An AI agent that analyzes a CV against a job description and suggests improvements.
 *
 * - suggestCvImprovements - A function that handles the CV improvement suggestion process.
 * - SuggestCvImprovementsInput - The input type for the suggestCvImprovements function.
 * - SuggestCvImprovementsOutput - The return type for the suggestCvImprovements function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestCvImprovementsInputSchema = z.object({
  cvContent: z.string().describe('The full content of the user\'s CV.'),
  jobDescription: z.string().describe('The job description to align the CV against.'),
});
export type SuggestCvImprovementsInput = z.infer<typeof SuggestCvImprovementsInputSchema>;

const SuggestCvImprovementsOutputSchema = z.object({
  improvements: z.string().describe('Detailed suggestions for improving the CV to better match the job description.'),
});
export type SuggestCvImprovementsOutput = z.infer<typeof SuggestCvImprovementsOutputSchema>;

export async function suggestCvImprovements(
  input: SuggestCvImprovementsInput
): Promise<SuggestCvImprovementsOutput> {
  return suggestCvImprovementsFlow(input);
}

const suggestCvImprovementsPrompt = ai.definePrompt({
  name: 'suggestCvImprovementsPrompt',
  input: {schema: SuggestCvImprovementsInputSchema},
  output: {schema: SuggestCvImprovementsOutputSchema},
  prompt: `You are an expert career coach and CV specialist. Your task is to analyze a user's CV and a specific job description. Your goal is to provide actionable and detailed suggestions on how to improve the CV to maximize its relevance for the given job description and increase the chances of an interview.

Focus on:
1.  **Keywords**: Identify keywords from the job description that are missing or underemphasized in the CV. Suggest where and how to incorporate them.
2.  **Skills**: Compare the required/desired skills in the job description with those listed in the CV. Suggest additions or rephrasing of skills to align better.
3.  **Experience**: For each relevant work experience in the CV, suggest how to rephrase or add bullet points to demonstrate alignment with the job description's responsibilities and requirements. Use strong action verbs and quantifiable achievements where possible.
4.  **Formatting/Structure**: If applicable, suggest minor structural or formatting improvements to enhance readability and impact for the specific job.
5.  **Overall Tone**: Recommend adjustments to the CV's tone to match the company culture or industry implied by the job description.

Provide your suggestions in a clear, structured, and easy-to-understand format.

Job Description:
{{{jobDescription}}}

User's CV:
{{{cvContent}}}`,
});

const suggestCvImprovementsFlow = ai.defineFlow(
  {
    name: 'suggestCvImprovementsFlow',
    inputSchema: SuggestCvImprovementsInputSchema,
    outputSchema: SuggestCvImprovementsOutputSchema,
  },
  async (input) => {
    const {output} = await suggestCvImprovementsPrompt(input);
    return output!;
  }
);
