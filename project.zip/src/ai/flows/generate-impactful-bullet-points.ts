'use server';
/**
 * @fileOverview A Genkit flow for generating high-impact bullet points for CV work experience.
 *
 * - generateBulletPoints - A function that handles the generation of bullet points.
 * - GenerateBulletPointsInput - The input type for the generateBulletPoints function.
 * - GenerateBulletPointsOutput - The return type for the generateBulletPoints function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateBulletPointsInputSchema = z.object({
  role: z.string().describe('The job role or title.'),
  company: z.string().describe('The name of the company.'),
  duration: z
    .string()
    .describe('The employment duration (e.g., "Jan 2020 - Dec 2022").'),
  responsibilities: z
    .string()
    .describe('A brief description of responsibilities in the role.'),
  achievements: z
    .string()
    .describe('Key achievements or contributions in the role.'),
  desiredTone: z
    .string()
    .optional()
    .describe(
      'Optional: The desired tone for the bullet points (e.g., "professional", "concise", "action-oriented").'
    ),
});
export type GenerateBulletPointsInput = z.infer<
  typeof GenerateBulletPointsInputSchema
>;

const GenerateBulletPointsOutputSchema = z.object({
  bulletPoints: z
    .array(z.string())
    .describe('An array of professional, high-impact bullet points.'),
});
export type GenerateBulletPointsOutput = z.infer<
  typeof GenerateBulletPointsOutputSchema
>;

export async function generateBulletPoints(
  input: GenerateBulletPointsInput
): Promise<GenerateBulletPointsOutput> {
  return generateBulletPointsFlow(input);
}

const generateBulletPointsPrompt = ai.definePrompt({
  name: 'generateBulletPointsPrompt',
  input: { schema: GenerateBulletPointsInputSchema },
  output: { schema: GenerateBulletPointsOutputSchema },
  prompt: `You are an expert CV writer and career coach specializing in creating high-impact work experience bullet points.
Your goal is to transform the provided responsibilities and achievements into compelling, quantifiable bullet points that stand out to recruiters.

Instructions:
- Generate 3-5 bullet points.
- Each bullet point must start with a strong action verb.
- Focus on achievements and the impact of the work, not just daily tasks.
- Quantify results whenever possible (e.g., "Increased sales by 15%", "Managed a team of 10").
- Keep bullet points concise and professional.
{{#if desiredTone}}
- Adopt a {{{desiredTone}}} tone.
{{/if}}

Here is the information for the role:
Role: {{{role}}}
Company: {{{company}}}
Duration: {{{duration}}}

Responsibilities:
{{{responsibilities}}}

Achievements:
{{{achievements}}}

Generate the bullet points in a JSON array format as specified by the output schema.`,
});

const generateBulletPointsFlow = ai.defineFlow(
  {
    name: 'generateBulletPointsFlow',
    inputSchema: GenerateBulletPointsInputSchema,
    outputSchema: GenerateBulletPointsOutputSchema,
  },
  async (input) => {
    const { output } = await generateBulletPointsPrompt(input);
    return output!;
  }
);
