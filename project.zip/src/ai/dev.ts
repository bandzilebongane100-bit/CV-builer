import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-cv-improvements.ts';
import '@/ai/flows/generate-impactful-bullet-points.ts';