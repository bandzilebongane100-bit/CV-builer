# **App Name**: EliteDraft

## Core Features:

- Live Resume Preview: Real-time, side-by-side preview of the professional CV document as the user enters their information.
- AI Content Tool: Generate high-impact bullet points for job descriptions using generative AI based on minimal user input.
- Template Gallery: A collection of clean, professional Next.js-powered templates optimized for ATS systems.
- Job Alignment Tool: Uses AI as a tool to compare the current CV against a specific job description and suggest improvements to increase relevance.
- Profile Persistence: Save and load CV drafts for later editing using an integrated cloud database.
- One-Click Export: Direct export of the finished CV into a perfectly formatted PDF document.

## Style Guidelines:

- Primary Color: Deep Navy (#122E54) used for headlines and navigation to evoke stability and trust.
- Background Color: Crisp Arctic Grey (#F5F7FA) for a clean, minimalist workspace.
- Accent Color: Azure Frost (#3A99D8) for primary action buttons and highlighting active sections.
- Font pairing: 'Literata' (serif) for formal document previews to provide a literary feel, and 'Inter' (sans-serif) for the workspace UI for objective clarity.
- Use sharp, thin-line monochrome icons for document sections like Education, Work, and Skills.
- A classic two-pane layout with an editor on the left and a scroll-locked A4 preview on the right.
- Soft horizontal slide transitions when switching between document templates.